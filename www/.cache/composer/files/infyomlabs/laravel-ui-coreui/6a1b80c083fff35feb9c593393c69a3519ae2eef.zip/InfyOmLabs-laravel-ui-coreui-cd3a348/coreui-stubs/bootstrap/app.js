require('./bootstrap');
require('@coreui/coreui/dist/js/coreui.bundle.min');

